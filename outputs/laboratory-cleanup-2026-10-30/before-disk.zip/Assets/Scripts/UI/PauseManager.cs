using StarterAssets; // Karakter kontrolcüsünü durdurmak için gerekli
using UnityEngine;
using UnityEngine.SceneManagement;

public class PauseManager : MonoBehaviour
{
    [Header("UI Referansları")]
    [SerializeField]
    private GameObject pauseMenuPanel;

    [SerializeField]
    private string mainMenuSceneName = "MainMenu"; // Ana menü sahnesinin tam adı

    [SerializeField]
    private GameObject settingsPanel; // <--- YENİ EKLENDİ

    [Header("Oyuncu Referansları")]
    [Tooltip("Karakterin Input Scripti (Mouse kilidini yönetmek için)")]
    [SerializeField]
    private StarterAssetsInputs playerInputs;

    private bool isPaused = false;

    private void Start()
    {
        // Başlangıçta panel kapalı olsun
        if (pauseMenuPanel != null)
            pauseMenuPanel.SetActive(false);
        if (settingsPanel != null)
            settingsPanel.SetActive(false); // <--- YENİ EKLENDİ
        // Oyun başladığında zamanın ve seslerin aktığından emin ol
        Time.timeScale = 1f;
        AudioListener.pause = false; // <--- GARANTİ OLSUN DİYE EKLENDİ

        // Input scriptini otomatik bulmaya çalış
        if (playerInputs == null)
            playerInputs = Object.FindFirstObjectByType<StarterAssetsInputs>();
    }

    private void Update()
    {
        if (SettingsMenuView.Open != null || Time.frameCount <= SettingsMenuView.LastClosedFrame) { if (playerInputs != null) playerInputs.pause = false; return; }
        // Oyun henüz başlamadıysa menü tuşunu yok say
        if (GameManager.Instance != null && !GameManager.Instance.isGameStarted)
            return;

        // YENİ: Input.GetKeyDown(KeyCode.Escape) yerine
        if (playerInputs != null && playerInputs.pause)
        {
            playerInputs.pause = false; // Tüketimi onayla ki menü sürekli açılıp kapanmasın

            if (settingsPanel != null && settingsPanel.activeSelf)
            {
                CloseSettings();
            }
            else if (isPaused)
            {
                ResumeGame();
            }
            else
            {
                PauseGame();
            }
        }
    }

    public void PauseGame()
    {
        isPaused = true;

        // 1. GameManager'a bildir
        if (GameManager.Instance != null)
            GameManager.Instance.isGamePaused = true;

        // 2. Zamanı Durdur
        Time.timeScale = 0f;

        // 3. SESLERİ DURDUR (YENİ EKLENEN KISIM)
        AudioListener.pause = true;

        // 4. Paneli Aç
        if (pauseMenuPanel != null)
            pauseMenuPanel.SetActive(true);

        GameManager.Instance.UpdateCursorState();
        // 6. Karakterin Kamera Dönüşünü Kilitle (StarterAssets için)
        if (playerInputs != null)
        {
            playerInputs.cursorInputForLook = false;
            playerInputs.look = Vector2.zero; // Mevcut ivmeyi sıfırla
        }

        Debug.Log("Oyun Duraklatıldı (Sesler Kesildi).");
    }

    public void ResumeGame()
    {
        isPaused = false;

        // 1. GameManager'a bildir
        if (GameManager.Instance != null)
            GameManager.Instance.isGamePaused = false;

        // 2. Zamanı Devam Ettir
        Time.timeScale = 1f;

        // 3. SESLERİ GERİ AÇ (YENİ EKLENEN KISIM)
        AudioListener.pause = false;

        // 4. Paneli Kapat
        if (pauseMenuPanel != null)
            pauseMenuPanel.SetActive(false);
        if (settingsPanel != null)
            settingsPanel.SetActive(false); // <--- YENİ: Garantilemek için
        // 5. Inputları geri aç
        if (playerInputs != null)
            playerInputs.cursorInputForLook = true;

        // --- KRİTİK DÜZELTME BURADA ---
        // Körlemesine fareyi kapatmak yerine, duruma göre karar veriyoruz.

        GameManager.Instance.UpdateCursorState();
    }

    public void OpenSettings()
    {
        if (pauseMenuPanel != null)
            pauseMenuPanel.SetActive(false);
        if (settingsPanel != null)
            settingsPanel.SetActive(true);
        var view = settingsPanel != null ? settingsPanel.GetComponentInChildren<SettingsMenuView>(true) : null;
        if (view != null) view.SetCloseAction(CloseSettingsImmediately);
    }

    public void CloseSettings()
    {
        var view = settingsPanel != null ? settingsPanel.GetComponentInChildren<SettingsMenuView>(true) : null;
        if (view != null) view.RequestClose(CloseSettingsImmediately); else CloseSettingsImmediately();
    }

    private void CloseSettingsImmediately()
    {
        var view = settingsPanel != null ? settingsPanel.GetComponentInChildren<SettingsMenuView>(true) : null;
        if (settingsPanel != null)
            settingsPanel.SetActive(false);
        if (pauseMenuPanel != null)
            pauseMenuPanel.SetActive(true);
        view?.RestoreFocusTo(pauseMenuPanel);
    }

    public void LoadMainMenu()
    {
        // Sahne değişirken zamanı mutlaka 1 yapmalıyız, yoksa menü donuk başlar!
        Time.timeScale = 1f;

        // Menüye dönünce sesler geri gelmeli (YENİ EKLENEN KISIM)
        AudioListener.pause = false;

        if (GameManager.Instance != null)
            GameManager.Instance.isGamePaused = false;

        SceneManager.LoadScene(mainMenuSceneName);
    }

    public void QuitToDesktop()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#endif
        Debug.Log("Masaüstüne Çıkılıyor...");
        Application.Quit();
    }
}
