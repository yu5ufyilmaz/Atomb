using System.Collections;
using Cinemachine;
// StarterAssets namespace'ini ekledim ki scripti tip güvenli bulabilelim
using StarterAssets;
using TMPro;
using UnityEngine;

public class InteractableOscilloscope : MonoBehaviour, IInteractable, IForceExitable
{
    [Header("Player Control")]
    [SerializeField]
    private UnityEngine.CharacterController playerController;
    private CinemachineVirtualCamera interactVCam;

    [SerializeField]
    private GameObject _playerFollowCamera;

    [SerializeField]
    private MonoBehaviour playerLookScript;

    [SerializeField]
    private Animator playerAnimator;

    [Header("⚠️ ÖNEMLİ: Hareket Scripti (Otomatik Bulunur ama Kontrol Et)")]
    [Tooltip("Karakterin yürümesini sağlayan ana script.")]
    public MonoBehaviour playerMovementScript;

    [Header("🎥 KAMERA AYARLARI (MUTLAKA ATANMALI)")]
    [Tooltip("Etkileşim başladığında kameranın gidip sabitleneceği nokta.")]
    public Transform fixedCameraTransform;

    [Header("📍 Etkileşim Pozisyonu")]
    public Transform interactionStandPoint;

    [SerializeField]
    private string interactAnimTrigger = "InspectScope";

    // ... Diğer Değişkenler ...
    [Header("Audio & Settings")]
    [SerializeField]
    private Transform voltsKnob;

    [SerializeField]
    private Transform timeKnob;

    [SerializeField]
    private float rotationPerStep = 36f;

    [SerializeField]
    private AudioSource stableAudioSource;

    [SerializeField]
    private AudioSource staticAudioSource;

    [SerializeField]
    private float pitchVariation = 0.5f;

    [SerializeField]
    private WaveformGenerator waveformScript;

    [SerializeField]
    private TextMeshPro screenText;

    [Header("Puzzle Logic")]
    [SerializeField]
    private int maxVoltsSetting = 10;

    [SerializeField]
    private int maxTimeSetting = 10;

    [SerializeField]
    private int correctVoltsSetting = 5;

    [SerializeField]
    private int correctTimeSetting = 5;

    private int currentVoltsSetting = 0;
    private int currentTimeSetting = 0;
    private bool isSolved = false;
    private bool isInteracting = false;
    private bool inMachineMode = false;
    private bool isExiting = false;
    private string assignedPassword = "";
    private Quaternion voltsKnobInitialRot;
    private Quaternion timeKnobInitialRot;
    private Coroutine audioFadeRoutine;

    [Header("Oscilloscope Mini-Game")]
    public float screenRadius = 5f; // Ekranın dairesel yarıçapı
    public float paddleAngle = 0f; // Raketin anlık açısı (0-360)
    public float paddleWidth = 40f; // Raketin genişliği (derece cinsinden, örn: 40 derece)
    public float paddleSpeed = 150f; // A/D tuşlarıyla dönüş hızı

    public Vector2 ballPosition;
    public Vector2 ballVelocity;
    public float ballSpeed = 3f;

    public int lives = 3;
    public int scoreToWin = 5; // Kazanmak için vurulacak hedef sayısı
    private int currentScore = 0;
    public Vector2 targetPosition; // Ekranda belirecek hedefin konumu
    private Transform mainCamera;
    private CinemachineBrain cinemachineBrain;

    void Start()
    {
        // 1. Player Controller Bul
        if (playerController == null)
            playerController = Object.FindFirstObjectByType<UnityEngine.CharacterController>();

        // 2. Diğer Scriptleri Bul (Özellikle Movement Script)
        if (playerController != null)
        {
            playerLookScript =
                playerController.GetComponent<StarterAssetsInputs>() as MonoBehaviour;
            playerAnimator = playerController.GetComponent<Animator>();

            // DÜZELTME BURADA: İsme göre ("ThirdPersonController") aramak yerine
            // direkt senin yüklediğin "StarterAssets.CharacterController" tipini arıyoruz.
            // Bu sayede scripti %100 bulur.
            if (playerMovementScript == null)
            {
                playerMovementScript =
                    playerController.GetComponent<StarterAssets.CharacterController>();
                // Eğer null dönerse diye log basalım
                if (playerMovementScript == null)
                    Debug.LogError(
                        "Osiloskop: Player Movement Script (StarterAssets.CharacterController) BULUNAMADI! Karakter titreyebilir."
                    );
            }
        }

        if (Camera.main != null)
        {
            mainCamera = Camera.main.transform;
            cinemachineBrain = mainCamera.GetComponent<CinemachineBrain>();
        }
        if (fixedCameraTransform != null)
        {
            interactVCam = fixedCameraTransform.GetComponentInChildren<CinemachineVirtualCamera>();
            if (interactVCam == null)
            {
                GameObject vcamObj = new GameObject("Oscilloscope_Interact_VCam");
                vcamObj.transform.parent = fixedCameraTransform;
                vcamObj.transform.localPosition = Vector3.zero;
                vcamObj.transform.localRotation = Quaternion.identity;
                interactVCam = vcamObj.AddComponent<CinemachineVirtualCamera>();
                interactVCam.Priority = 0;
                interactVCam.m_Lens.FieldOfView = 90f;
                interactVCam.m_Lens.NearClipPlane = 0.1f;
                interactVCam.m_Lens.FarClipPlane = 1000f;
            }
        }
        if (voltsKnob)
            voltsKnobInitialRot = voltsKnob.localRotation;
        if (timeKnob)
            timeKnobInitialRot = timeKnob.localRotation;

        // Audio Başlat
        if (stableAudioSource)
        {
            stableAudioSource.loop = true;
            stableAudioSource.volume = 0f;
        }
        if (staticAudioSource)
        {
            staticAudioSource.loop = true;
            staticAudioSource.volume = 0f;
        }

        currentVoltsSetting = 2;
        currentTimeSetting = 2;
        UpdateKnobVisuals();
    }

    public void Interact()
    {
        if (isInteracting || isExiting || isSolved)
            return;

        // Hata ayıklama: Fixed Transform yoksa uyar
        if (fixedCameraTransform == null)
        {
            Debug.LogError("Osiloskop: Fixed Camera Transform ATANMAMIŞ! Kamera geçiş yapamaz.");
            return;
        }

        StartCoroutine(MoveToInteractionPoint());
    }

    public string GetInteractionPrompt() =>
        isSolved ? "Sinyal Stabil" : (isInteracting ? "" : "[Sol Tık] Sinyali Düzelt");

    // --- SİNEMATİK OTURTMA (OSİLOSKOP) ---
    private IEnumerator MoveToInteractionPoint()
    {
        isInteracting = true;
        inMachineMode = false;

        // 1. İNPUTLARI VE KAMERA KONTROLÜNÜ DONDUR
        StarterAssets.CharacterController saController =
            playerMovementScript as StarterAssets.CharacterController;
        if (saController != null)
        {
            saController.SetFrozen(true, lockCameraInput: true, restrictRotation: false);
        }
        if (playerLookScript)
            playerLookScript.enabled = false;

        // 2. SCRİPTİ VE FİZİĞİ KAPAT (Konsol hatalarını ve titremeyi önler)
        if (playerMovementScript)
            playerMovementScript.enabled = false;
        if (playerController)
            playerController.enabled = false;

        // 3. YUMUŞAK GEÇİŞ (0.5 Saniyede Pürüzsüzce Masaya Geçiş)
        if (interactionStandPoint != null)
        {
            float duration = 0.5f;
            float t = 0f;
            Vector3 startPos = playerController.transform.position;
            Quaternion startRot = playerController.transform.rotation;

            if (playerAnimator)
            {
                playerAnimator.SetFloat("Speed", 0f);
                playerAnimator.SetFloat("MotionSpeed", 0f);
            }

            while (t < duration)
            {
                t += Time.deltaTime;
                float smoothT = Mathf.SmoothStep(0f, 1f, t / duration);

                playerController.transform.position = Vector3.Lerp(
                    startPos,
                    interactionStandPoint.position,
                    smoothT
                );
                playerController.transform.rotation = Quaternion.Slerp(
                    startRot,
                    interactionStandPoint.rotation,
                    smoothT
                );
                yield return null;
            }

            playerController.transform.position = interactionStandPoint.position;
            playerController.transform.rotation = interactionStandPoint.rotation;
        }

        StartCoroutine(EnterMachineView());
    }

    private IEnumerator EnterMachineView()
    {
        if (GameManager.Instance != null)
            GameManager.Instance.activeInteraction = this;

        if (playerAnimator)
            playerAnimator.SetTrigger(interactAnimTrigger);

        // VCAM AKTİF ET (Manuel Lerp ve Brain kapatmaya gerek kalmadı, sistem süzülecek)
        if (interactVCam)
        {
            interactVCam.Priority = 102;
            _playerFollowCamera.SetActive(false);
        }

        yield return new WaitForSeconds(1.5f); // Kameranın süzülmesini bekle

        inMachineMode = true;

        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;

        if (ControlsUIManager.Instance != null)
        {
            ControlsUIManager.Instance.ShowMachineUI(ControlsUIManager.MachineType.Oscilloscope);
        }

        PlayerInteraction playerInt = Object.FindFirstObjectByType<PlayerInteraction>();
        if (playerInt != null)
            playerInt.ToggleCrosshair(false);

        FadeAudio(true, 1.0f);
        UpdateAudioAndWaveform();
        UpdateKnobVisuals();
    }

    private IEnumerator ExitMachineView()
    {
        if (isExiting)
            yield break;
        isExiting = true;
        inMachineMode = false;

        FadeAudio(false, 0.5f);

        if (interactVCam)
        {
            interactVCam.Priority = 0;
            if (_playerFollowCamera != null)
            {
                _playerFollowCamera.SetActive(true); // KAMERAYI GERİ AÇIYORUZ
            }
        }

        yield return new WaitForSeconds(1.5f);

        // 1. FİZİĞİ VE SCRİPTİ GERİ AÇ
        if (playerController)
            playerController.enabled = true;
        if (playerMovementScript)
            playerMovementScript.enabled = true;

        // 2. HAREKET KİLİDİNİ ÇÖZ
        StarterAssets.CharacterController saController =
            playerMovementScript as StarterAssets.CharacterController;
        if (saController != null)
        {
            saController.SetFrozen(false, lockCameraInput: false, restrictRotation: false);
        }
        if (playerLookScript)
            playerLookScript.enabled = true;

        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;

        PlayerInteraction playerInt = Object.FindFirstObjectByType<PlayerInteraction>();
        if (playerInt != null)
            playerInt.ToggleCrosshair(true);

        if (ControlsUIManager.Instance != null)
            ControlsUIManager.Instance.HideControls();
        if (GameManager.Instance != null)
            GameManager.Instance.activeInteraction = null;

        isInteracting = false;
        isExiting = false;
        PlayerInteraction.NotifyInteractionExit(gameObject);
    }

    private void Update()
    {
        if (!inMachineMode || isExiting)
            return;

        // ÇIKIŞ
        if (GameInput.Pressed("Cancel"))
        {
            StartCoroutine(ExitMachineView());
            return;
        }

        if (isSolved)
        {
            if (waveformScript)
                waveformScript.frequency = 1.0f;
            return;
        }

        // KONTROLLER
        bool changed = false;
        if (GameInput.Pressed("DeviceUp"))
        {
            currentVoltsSetting = Mathf.Min(currentVoltsSetting + 1, maxVoltsSetting);
            changed = true;
        }
        else if (GameInput.Pressed("DeviceDown"))
        {
            currentVoltsSetting = Mathf.Max(currentVoltsSetting - 1, 0);
            changed = true;
        }

        if (GameInput.Pressed("DeviceRight"))
        {
            currentTimeSetting = Mathf.Min(currentTimeSetting + 1, maxTimeSetting);
            changed = true;
        }
        else if (GameInput.Pressed("DeviceLeft"))
        {
            currentTimeSetting = Mathf.Max(currentTimeSetting - 1, 0);
            changed = true;
        }

        if (changed)
        {
            UpdateKnobVisuals();
            UpdateAudioAndWaveform();
            CheckForSolution();
        }
    }

    // --- YARDIMCI FONKSİYONLAR ---
    private void UpdateAudioAndWaveform()
    {
        float voltsDiff = Mathf.Abs(currentVoltsSetting - correctVoltsSetting);
        float timeDiff = Mathf.Abs(currentTimeSetting - correctTimeSetting);
        float maxError = maxVoltsSetting + maxTimeSetting;
        float currentError = voltsDiff + timeDiff;
        float accuracy = 1.0f - (currentError / maxError);
        accuracy = Mathf.Clamp01(accuracy);

        if (audioFadeRoutine == null)
        {
            float stableVol = Mathf.Pow(accuracy, 2);
            float staticVol = 1.0f - accuracy;
            if (stableAudioSource)
                stableAudioSource.volume = stableVol;
            if (staticAudioSource)
                staticAudioSource.volume = staticVol * 0.5f;
        }

        float targetPitch = 1.0f + ((0.5f - accuracy) * pitchVariation);
        if (stableAudioSource)
            stableAudioSource.pitch = isSolved ? 1.0f : targetPitch;
        if (staticAudioSource)
            staticAudioSource.pitch = Random.Range(0.8f, 1.2f);

        if (waveformScript)
        {
            float vRatio = (float)currentVoltsSetting / maxVoltsSetting;
            float tRatio = (float)currentTimeSetting / maxTimeSetting;
            waveformScript.amplitude = Mathf.Lerp(0.2f, 2.5f, vRatio);
            waveformScript.frequency = Mathf.Lerp(0.5f, 3.0f, tRatio);
            if (isSolved)
                waveformScript.noiseAmount = 0f;
            else
                waveformScript.noiseAmount = Mathf.Lerp(0.8f, 0f, accuracy);
        }
    }

    private void FadeAudio(bool fadeIn, float duration)
    {
        if (audioFadeRoutine != null)
            StopCoroutine(audioFadeRoutine);
        audioFadeRoutine = StartCoroutine(FadeAudioRoutine(fadeIn, duration));
    }

    private IEnumerator FadeAudioRoutine(bool fadeIn, float duration)
    {
        float t = 0f;
        float startStable = stableAudioSource ? stableAudioSource.volume : 0;
        float startStatic = staticAudioSource ? staticAudioSource.volume : 0;
        float initialStableTarget = stableAudioSource ? stableAudioSource.volume : 0;
        float initialStaticTarget = staticAudioSource ? staticAudioSource.volume : 0;

        if (fadeIn)
        {
            if (stableAudioSource && !stableAudioSource.isPlaying)
                stableAudioSource.Play();
            if (staticAudioSource && !staticAudioSource.isPlaying)
                staticAudioSource.Play();
            UpdateAudioAndWaveform();
        }

        while (t < duration)
        {
            t += Time.deltaTime;
            float ratio = t / duration;
            if (fadeIn)
            {
                if (stableAudioSource)
                    stableAudioSource.volume = Mathf.Lerp(0, initialStableTarget, ratio);
                if (staticAudioSource)
                    staticAudioSource.volume = Mathf.Lerp(0, initialStaticTarget, ratio);
            }
            else
            {
                if (stableAudioSource)
                    stableAudioSource.volume = Mathf.Lerp(startStable, 0, ratio);
                if (staticAudioSource)
                    staticAudioSource.volume = Mathf.Lerp(startStatic, 0, ratio);
            }
            yield return null;
        }
        if (!fadeIn)
        {
            if (stableAudioSource)
                stableAudioSource.Stop();
            if (staticAudioSource)
                staticAudioSource.Stop();
        }
        audioFadeRoutine = null;
    }

    private void UpdateKnobVisuals()
    {
        if (voltsKnob)
            voltsKnob.localRotation =
                voltsKnobInitialRot * Quaternion.Euler(0, currentVoltsSetting * rotationPerStep, 0);
        if (timeKnob)
            timeKnob.localRotation =
                timeKnobInitialRot * Quaternion.Euler(0, currentTimeSetting * rotationPerStep, 0);
    }

    private void CheckForSolution()
    {
        if (currentVoltsSetting == correctVoltsSetting && currentTimeSetting == correctTimeSetting)
        {
            isSolved = true;
            if (screenText != null)
            {
                GameLocalization.SetFormat(screenText, "STABLE\nKEY: {0}", assignedPassword);
                screenText.color = Color.green;
            }
            if (PasswordManager.Instance != null)
                PasswordManager.Instance.DiscoverClue(assignedPassword);
            if (staticAudioSource)
                staticAudioSource.volume = 0;
            if (stableAudioSource)
            {
                stableAudioSource.volume = 1f;
                stableAudioSource.pitch = 1f;
            }
            StartCoroutine(AutoExit(1.5f));
        }
    }

    public void OnFocus() { }

    public void OnLoseFocus() { }

    public void AssignPassword(string pw)
    {
        assignedPassword = pw;
        if (screenText != null)
            GameLocalization.Set(screenText, "NO SIGNAL");
    }

    private IEnumerator AutoExit(float delay)
    {
        yield return new WaitForSeconds(delay);
        if (inMachineMode)
            StartCoroutine(ExitMachineView());
    }

    public void ForceExit()
    {
        if (inMachineMode)
            StartCoroutine(ExitMachineView());
    }
}
