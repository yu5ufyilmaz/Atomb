using System.Collections;
using System.Collections.Generic;
using Cinemachine;
using StarterAssets;
using UnityEngine;
using UnityEngine.Playables;
using UnityEngine.Rendering; // YENİ EKLENDİ
using UnityEngine.Rendering.HighDefinition; // YENİ EKLENDİ

public class LeesEnemyAI : MonoBehaviour
{
    public static LeesEnemyAI Instance;

    public enum LeesState
    {
        Hidden,
        Active,
        Jumpscare,
    }

    public LeesState currentState = LeesState.Hidden;
    public bool ignorePlayer = false;

    [Header("Model & Animasyon")]
    public Animator leesAnimator;
    private static readonly int JumpscareTrigger = Animator.StringToHash("Jumpscare");

    [Header("Timeline Jumpscare")]
    public PlayableDirector timelineJumpscare;

    [Tooltip("Arkadan (Odadan çıkarken vb.) yakaladığında oynayacak Timeline")]
    public PlayableDirector timelineJumpscareBehind; // <--- YENİ EKLENDİ

    [Header("Görüş Ayarları")]
    public LayerMask obstacleMask;
    public Transform eyesPosition;

    [Tooltip("0.0 = Tam ekran, 0.2 = Ekranın kenarlarından %20'lik kısım güvenli")]
    [Range(0f, 0.4f)]
    public float screenEdgeBuffer = 0.1f;

    private int visionLayerMask;

    [Header("Oda ve Şans Sistemi")]
    [SerializeField]
    private RoomManager currentRoom;
    private RoomManager spawnRoom;

    [SerializeField]
    private float timeSpentInCurrentRoom;

    public float baseSpawnChance = 10f;
    public float chanceIncreasePerSecond = 2f;
    public float spawnCheckInterval = 5f;

    [Header("Senaryo Ayarları")]
    public float maxIgnoranceTime = 30f;
    public float maxReactionTime = 3.0f;
    public float survivalWaitTime = 15f;
    public float movementTolerance = 0.5f;
    public float movementGraceTime = 0.5f;

    private float currentMovementGraceTimer = 0f;

    [Header("Ses Efektleri")]
    public AudioSource audioSource;
    public float audioFadeDuration = 2.0f;
    public AudioClip stareSound;
    public AudioClip jumpscareSound;

    [Header("Jumpscare Ayarları")]
    public float jumpscareDistance = 1.2f;
    public float jumpscareYOffset = -0.5f;

    // --- YENİ EKLENEN KISIM ---
    public JumpscareProfile leesJumpscareProfile;

    // ---------------------------

    [Header("Spawn Sıklığı")]
    public float spawnCooldownAfterDespawn = 20f;
    private float currentCooldownTimer = 0f;

    [Header("DEBUG AYARLARI (Canlı Veriler)")]
    public bool showDebugLogs = true;
    public float debugCooldownTimer;
    public float debugReactionTimer;
    public float debugSurvivalTimer;
    public float debugIgnoranceTimer;
    public bool debugIsVisible;
    public bool debugHasBeenSpotted;

    private float currentIgnoranceTimer;
    private float currentReactionTimer;
    private float currentSurvivalTimer;
    public bool HasBeenSpotted = false;

    // Private olan hasBeenSpotted değişkenini Event Controller'ın okuyabilmesi için dışarı açtık.
    private bool hasTurnedAway = false;
    private Vector3 lastPlayerPos;

    private Coroutine audioFadeRoutine;

    [Header("Referanslar")]
    public Transform playerTransform;
    public Camera playerCamera;
    private UnityEngine.CharacterController targetCharacterController;
    private StarterAssetsInputs playerInputs;
    public MonoBehaviour playerMovementScript;
    public MonoBehaviour playerLookScript;
    [Header("Başı Çevirmeye Direnme")]
    public LeesResistanceController resistance;
    private Vector3 resistanceApproachStart;
    private Vector3 resistanceApproachForward;
    public bool IsPracticeEncounter => isSafeSpawn && TutorialManager.Instance != null && TutorialManager.Instance.IsRunning;
    private Coroutine shockRoutine;
    private float shockBaseFov;

    // RAM Optimizasyonu: Önbelleklenmiş renderer ve collider'lar
    private Renderer[] cachedRenderers;
    private Collider[] cachedColliders;

    // RAM Optimizasyonu: Spawn noktası shuffle için yeniden kullanılabilir liste
    private List<Transform> shuffleBuffer = new List<Transform>();
    public bool isSafeSpawn = false;

    [Header("Şok (Fark Edilme) Efekti")]
    public bool useShockEffect = true;
    public float shockDuration = 0.5f;
    public float peakFOVOffset = -15f; // FOV'u daraltıp ani zoom yapar
    public float peakVignette = 0.65f;
    public float peakLensDistortion = -0.7f;
    public float peakAberration = 1f;
    public AudioClip shockSound;
    private Volume globalVolume;
    private Vignette m_Vignette;
    private LensDistortion m_LensDistortion;
    private ChromaticAberration m_Aberration;
    private float baseVignette;
    private float baseLens;
    private float baseAberration;

    private void Awake()
    {
        if (Instance == null)
            Instance = this;

        // RAM Optimizasyonu: Renderer ve Collider'ları önbelleğe al
        cachedRenderers = GetComponentsInChildren<Renderer>();
        cachedColliders = GetComponentsInChildren<Collider>();
    }

    private void Start()
    {
        if (playerTransform == null)
        {
            GameObject playerObj = GameObject.FindGameObjectWithTag("Player");
            if (playerObj != null)
                playerTransform = playerObj.transform;
        }

        if (playerTransform != null)
        {
            targetCharacterController =
                playerTransform.GetComponent<UnityEngine.CharacterController>();
            playerInputs = playerTransform.GetComponent<StarterAssetsInputs>();
        }

        if (playerCamera == null)
            playerCamera = Camera.main;
        if (resistance != null)
        {
            // A gameplay enemy must never inherit the standalone workshop's retry/pause settings.
            resistance.keepResultVisible = false; resistance.useGamePause = true;
            resistance.playerMovement = playerTransform.GetComponent<StarterAssets.CharacterController>();
        }

        if (audioSource != null)
        {
            audioSource.loop = true;
            audioSource.volume = 0f;
        }
        globalVolume = Object.FindFirstObjectByType<Volume>();
        if (globalVolume != null && globalVolume.profile != null)
        {
            globalVolume.profile.TryGet(out m_Vignette);
            globalVolume.profile.TryGet(out m_LensDistortion);
            globalVolume.profile.TryGet(out m_Aberration);

            if (m_Vignette != null)
                baseVignette = m_Vignette.intensity.value;
            if (m_LensDistortion != null)
                baseLens = m_LensDistortion.intensity.value;
            if (m_Aberration != null)
                baseAberration = m_Aberration.intensity.value;
        }
        visionLayerMask = ~LayerMask.GetMask("Player", "UI", "IgnoreRaycast", "TransparentFX");

        DespawnLees();
        InvokeRepeating(nameof(CheckSpawnLogic), 5f, spawnCheckInterval);
    }

    private void Update()
    {
        if (GameManager.Instance == null || !GameManager.Instance.isGameStarted)
            return;
        if (GlobalEnemyManager.Instance != null && GlobalEnemyManager.Instance.stopAllEnemies)
        {
            if (resistance != null && resistance.IsRunning) DespawnLees();
            return; // Eğer sistem durdurulmuşsa hiçbir sayacı ilerletme, burada kal!
        }
        if (currentCooldownTimer > 0)
        {
            currentCooldownTimer -= Time.deltaTime;
#if UNITY_EDITOR
            debugCooldownTimer = currentCooldownTimer;
#endif
        }

        if (currentState == LeesState.Hidden && currentRoom != null && currentRoom.isDangerous)
        {
            timeSpentInCurrentRoom += Time.deltaTime;
        }

        if (currentState == LeesState.Active)
        {
            HandleActiveLogic();
        }

#if UNITY_EDITOR
        debugReactionTimer = currentReactionTimer;
        debugSurvivalTimer = currentSurvivalTimer;
        debugIgnoranceTimer = currentIgnoranceTimer;
        if (showDebugLogs)
            debugIsVisible = CheckIfVisible();
        debugHasBeenSpotted = HasBeenSpotted;
#endif
    }

    private void HandleActiveLogic()
    {
        if (Time.deltaTime <= 0 || playerTransform == null) return;
        float playerSpeed =
            Vector3.Distance(playerTransform.position, lastPlayerPos) / Time.deltaTime;
        lastPlayerPos = playerTransform.position;

        if (currentRoom != spawnRoom)
        {
            TriggerDeath("There is no escape.", true);
            return;
        }
        if (resistance != null && resistance.IsRunning)
        {
            HandleResistance(playerSpeed);
            return;
        }

        bool isPlayerControllable = (
            targetCharacterController != null && targetCharacterController.enabled
        );
        bool logicVisible = CheckIfVisible();

        if (!isPlayerControllable && !HasBeenSpotted)
            logicVisible = false;

        if (!HasBeenSpotted)
        {
            if (logicVisible)
            {
                HasBeenSpotted = true;
                hasTurnedAway = false;
                currentReactionTimer = 0f;
                currentMovementGraceTimer = 0f;

                if (resistance == null && audioSource && stareSound)
                    StartFadeAudio(stareSound, true);
                if (useShockEffect)
                    shockRoutine = StartCoroutine(ShockRoutine());
                Debug.Log("Lees: FARK EDİLDİ!");
            }
            else
            {
                currentIgnoranceTimer += Time.deltaTime;
                if (currentIgnoranceTimer >= maxIgnoranceTime)
                    TriggerDeath("You ignored him.");
            }
        }
        else
        {
            if (logicVisible)
            {
                if (hasTurnedAway)
                {
                    TriggerDeath("You look him again.");
                    return;
                }
                currentReactionTimer += Time.deltaTime;
                currentSurvivalTimer = 0f;

                if (currentReactionTimer >= maxReactionTime)
                    TriggerDeath("You stared too long.");
            }
            else
            {
                Vector3 towardLees = transform.position - playerCamera.transform.position;
                towardLees.y = 0;
                Vector3 look = playerCamera.transform.forward; look.y = 0;
                bool facingAway = Vector3.Dot(look.normalized, towardLees.normalized) < -.65f;
                // Frustum changes and brief occlusion are not the player turning their back.
                hasTurnedAway |= facingAway;
                bool isInputting = (playerInputs != null && playerInputs.move != Vector2.zero);

                if (isInputting && playerSpeed > movementTolerance)
                {
                    currentMovementGraceTimer += Time.deltaTime;
                    if (currentMovementGraceTimer >= movementGraceTime)
                    {
                        TriggerDeath("You moved.");
                    }
                }
                else
                {
                    currentMovementGraceTimer = 0f;
                    if (resistance != null)
                    {
                        if (facingAway
                            && !isInputting && isPlayerControllable && GameManager.Instance.activeInteraction == null)
                        {
                            StopShock(); StopEncounterAudio();
                            resistanceApproachStart = transform.position;
                            resistanceApproachForward = look.normalized;
                            resistance.BeginResistance();
                        }
                        return; // The old waiting timer must not bypass the resistance encounter.
                    }
                    currentSurvivalTimer += Time.deltaTime;
                    currentReactionTimer = Mathf.Max(0, currentReactionTimer - Time.deltaTime);

                    if (currentSurvivalTimer >= survivalWaitTime)
                    {
                        Debug.Log("Lees: Başarılı kurtuluş.");
                        DespawnLees();
                    }
                }
            }
        }
    }

    private void HandleResistance(float playerSpeed)
    {
        if (resistance.IsPaused) return;
        if (resistance.Model.State != LeesResistanceModel.Phase.Approaching && resistance.Model.State != LeesResistanceModel.Phase.Struggling) return;
        bool moving = (playerInputs != null && playerInputs.move.sqrMagnitude > .01f) || playerSpeed > movementTolerance;
        currentMovementGraceTimer = moving ? currentMovementGraceTimer + Time.deltaTime : 0;
        if (currentMovementGraceTimer >= movementGraceTime) { TriggerDeath("You moved.", true); return; }
        if (resistance.Model.State == LeesResistanceModel.Phase.Approaching)
        {
            if (CheckIfVisible()) { TriggerDeath("You look him again.", true); return; }
            Vector3 behind = playerTransform.position - resistanceApproachForward * 1.15f; behind.y = resistanceApproachStart.y;
            float progress = resistance.Model.Elapsed / Mathf.Max(.01f, resistance.tuning.approachSeconds);
            transform.position = Vector3.Lerp(resistanceApproachStart, behind, Mathf.SmoothStep(0, 1, progress));
            Vector3 facing = playerTransform.position - transform.position; facing.y = 0;
            if (facing.sqrMagnitude > .001f) transform.rotation = Quaternion.LookRotation(facing);
        }
    }
    public void ResistanceEscaped()
    {
        if (currentState != LeesState.Active) return;
        if (playerInputs != null) playerInputs.look = Vector2.zero;
        DespawnLees();
    }
    public void ResistanceCaught()
    {
        if (currentState != LeesState.Active) return;
        if (IsPracticeEncounter)
        {
            currentMovementGraceTimer = 0;
            resistanceApproachStart = transform.position;
            resistanceApproachForward = playerCamera.transform.forward; resistanceApproachForward.y = 0;
            resistanceApproachForward.Normalize();
            resistance.BeginResistance();
            return;
        }
        TriggerDeath("He turned your head.", true);
    }
    private void StopEncounterAudio()
    {
        if (audioFadeRoutine != null) { StopCoroutine(audioFadeRoutine); audioFadeRoutine = null; }
        if (audioSource != null) { audioSource.Stop(); audioSource.volume = 0; }
    }
    private void StopShock()
    {
        if (shockRoutine == null) return;
        StopCoroutine(shockRoutine); shockRoutine = null;
        if (playerCamera != null) playerCamera.fieldOfView = shockBaseFov;
        if (m_Vignette != null) m_Vignette.intensity.Override(baseVignette);
        if (m_LensDistortion != null) m_LensDistortion.intensity.Override(baseLens);
        if (m_Aberration != null) m_Aberration.intensity.Override(baseAberration);
    }
    private void OnDisable() { StopShock(); if (resistance != null) resistance.CancelResistance(); }

    private IEnumerator ShockRoutine()
    {
        // 1. Sesi Patlat (Eğer atandıysa)
        if (resistance == null && shockSound != null && audioSource != null)
        {
            // Orijinal sesi kesmemesi için PlayOneShot kullanıyoruz
            audioSource.PlayOneShot(shockSound);
        }

        float elapsed = 0f;
        float baseFOV = playerCamera != null ? playerCamera.fieldOfView : 60f;
        shockBaseFov = baseFOV;
        float targetFOV = baseFOV + peakFOVOffset;

        while (elapsed < shockDuration)
        {
            // Zaman durdurmalarından etkilenmemesi için unscaledDeltaTime
            elapsed += Time.unscaledDeltaTime;

            // Mathf.Sin ile 0'dan 1'e ulaşıp tekrar 0'a inen pürüzsüz bir dalga (glitch) yaratıyoruz
            float t = elapsed / shockDuration;
            float shockCurve = Mathf.Sin(t * Mathf.PI);

            // FOV Sarsıntısı (Ani zoom)
            if (playerCamera != null)
                playerCamera.fieldOfView = Mathf.Lerp(baseFOV, targetFOV, shockCurve);

            // Post Process Bükülmeleri
            if (m_Vignette != null)
                m_Vignette.intensity.Override(Mathf.Lerp(baseVignette, peakVignette, shockCurve));
            if (m_LensDistortion != null)
                m_LensDistortion.intensity.Override(
                    Mathf.Lerp(baseLens, peakLensDistortion, shockCurve)
                );
            if (m_Aberration != null)
                m_Aberration.intensity.Override(
                    Mathf.Lerp(baseAberration, peakAberration, shockCurve)
                );

            yield return null;
        }

        // 2. Garanti Sıfırlama (Her şeyi asıl değerlerine geri koy)
        if (playerCamera != null)
            playerCamera.fieldOfView = baseFOV;
        if (m_Vignette != null)
            m_Vignette.intensity.Override(baseVignette);
        if (m_LensDistortion != null)
            m_LensDistortion.intensity.Override(baseLens);
        if (m_Aberration != null)
            m_Aberration.intensity.Override(baseAberration);
        shockRoutine = null;
    }

    private bool CheckIfVisible()
    {
        if (playerCamera == null)
            return false;

        Vector3 targetPoint =
            (eyesPosition != null) ? eyesPosition.position : transform.position + Vector3.up * 1.5f;
        Vector3 viewportPoint = playerCamera.WorldToViewportPoint(targetPoint);
        if (viewportPoint.z <= 0)
            return false;

        if (
            viewportPoint.x < screenEdgeBuffer
            || viewportPoint.x > (1f - screenEdgeBuffer)
            || viewportPoint.y < screenEdgeBuffer
            || viewportPoint.y > (1f - screenEdgeBuffer)
        )
            return false;

        Vector3 origin = playerCamera.transform.position + playerCamera.transform.forward * 0.3f;
        Vector3 direction = targetPoint - origin;
        float distance = direction.magnitude;
        RaycastHit hit;

        if (
            Physics.Raycast(
                origin,
                direction,
                out hit,
                distance,
                visionLayerMask,
                QueryTriggerInteraction.Collide
            )
        )
        {
            if (hit.transform == transform || hit.transform.IsChildOf(transform))
            {
#if UNITY_EDITOR
                if (showDebugLogs)
                    Debug.DrawLine(origin, hit.point, Color.green);
#endif
                return true;
            }
            else
            {
#if UNITY_EDITOR
                if (showDebugLogs)
                    Debug.DrawLine(origin, hit.point, Color.red);
#endif
                return false;
            }
        }
        return false;
    }

    public void TriggerDeath(string reason, bool spawnBehind = false)
    {
        if (IsPracticeEncounter)
        {
            if (resistance != null && resistance.IsRunning) resistance.CatchForMovement();
            return;
        }
        if (currentState == LeesState.Jumpscare)
            return;
        StopShock();
        if (resistance != null) resistance.CancelResistance();
        if (playerInputs != null) playerInputs.look = Vector2.zero;

        // ÇÖZÜM BURADA: Ölüm tetiklendiği an durumu Jumpscare'e alıyoruz ki
        // Update() içindeki HandleActiveLogic her frame'de burayı tekrar çağırmasın.
        currentState = LeesState.Jumpscare;

        if (targetCharacterController != null && !targetCharacterController.enabled)
        {
            StartCoroutine(ForceExitAndKillRoutine(reason, spawnBehind));
            return;
        }
        ExecuteDeathNow(reason, spawnBehind);
    }

    private IEnumerator ForceExitAndKillRoutine(string reason, bool spawnBehind)
    {
        if (GameManager.Instance != null && GameManager.Instance.activeInteraction != null)
            GameManager.Instance.activeInteraction.ForceExit();

        float maxWait = 6.0f;
        float timer = 0f;

        while (
            targetCharacterController != null
            && !targetCharacterController.enabled
            && timer < maxWait
        )
        {
            timer += Time.deltaTime;
            yield return null;
        }
        yield return new WaitForSeconds(0.2f);
        ExecuteDeathNow(reason, spawnBehind);
    }

    private void ExecuteDeathNow(string reason, bool spawnBehind)
    {
        Debug.LogError($"ÖLÜM: {reason}");
        currentState = LeesState.Jumpscare; // Kilitleme

        // Eğer Inspector'dan Timeline atandıysa YENİ sistemi çalıştır
        if (timelineJumpscare != null)
        {
            StartCoroutine(ExecuteTimelineJumpscareRoutine(reason));
        }
        else
        {
            // Eski sistem (Timeline yoksa çalışır)
            if (audioFadeRoutine != null)
                StopCoroutine(audioFadeRoutine);
            if (audioSource)
            {
                audioSource.Stop();
                audioSource.volume = 1.0f;
                if (jumpscareSound)
                    audioSource.PlayOneShot(jumpscareSound);
            }
            if (leesAnimator != null)
                leesAnimator.SetTrigger(JumpscareTrigger);

            if (spawnBehind)
                StartCoroutine(ExecuteBehindJumpscare(reason));
            else
                StartCoroutine(ExecuteSmartJumpscare(reason));
        }
    }

    private IEnumerator ExecuteTimelineJumpscareRoutine(string reason)
    {
        // 1. HARİTADAKİ LEES'İ GİZLE
        ShowModel(false);
        if (NotebookUI.Instance != null)
        {
            NotebookUI.Instance.ForceClose();
        }
        // 2. OYUNCU KONTROLLERİNİ TAMAMEN DONDUR VE FİŞİNİ ÇEK
        if (playerInputs != null)
        {
            playerInputs.cursorInputForLook = false;
            playerInputs.move = Vector2.zero;
            playerInputs.enabled = false;
        }

        if (targetCharacterController != null)
            targetCharacterController.enabled = false;

        var playerMoveScript = playerTransform.GetComponent<StarterAssets.CharacterController>();
        if (playerMoveScript != null)
        {
            playerMoveScript.SetFrozen(true, lockCameraInput: true, restrictRotation: false);
            playerMoveScript.enabled = false;
        }

        // KAMERA BEYNİNİ KAPATMA KISMI SİLİNDİ! (Timeline kamerayı kendi devralacak)

        // 4. TIMELINE'I BAŞLAT
        timelineJumpscare.Play();

        // 5. TIMELINE'IN BİTMESİNİ BEKLE
        yield return new WaitForSeconds((float)timelineJumpscare.duration);

        // 6. ÖLÜM EKRANINI ÇAĞIR
        if (DeathUIManager.Instance != null)
            DeathUIManager.Instance.ShowDeathScreen(reason);
    }

    private void StartFadeAudio(AudioClip clip, bool fadeIn)
    {
        if (audioSource == null)
            return;
        if (audioFadeRoutine != null)
            StopCoroutine(audioFadeRoutine);
        audioFadeRoutine = StartCoroutine(FadeAudioRoutine(clip, fadeIn));
    }

    private IEnumerator FadeAudioRoutine(AudioClip clip, bool fadeIn)
    {
        float targetVolume = fadeIn ? 1.0f : 0.0f;
        float startVolume = audioSource.volume;
        float timer = 0f;

        if (fadeIn)
        {
            audioSource.clip = clip;
            if (!audioSource.isPlaying)
                audioSource.Play();
        }

        while (timer < audioFadeDuration)
        {
            timer += Time.deltaTime;
            audioSource.volume = Mathf.Lerp(startVolume, targetVolume, timer / audioFadeDuration);
            yield return null;
        }
        audioSource.volume = targetVolume;
        if (!fadeIn)
            audioSource.Stop();
    }

    // --- JUMPSCARE GÜNCELLEMELERİ ---
    // STRING REASON PARAMETRESİNİ EKLİYORUZ
    private IEnumerator ExecuteBehindJumpscare(string reason)
    {
        currentState = LeesState.Jumpscare;
        ShowModel(true);
        if (JumpscareManager.Instance != null)
        {
            // REASON'I JUMPSCARE MANAGER'A İLETİYORUZ
            JumpscareManager.Instance.StartJumpscare(
                transform,
                leesJumpscareProfile,
                true,
                JumpscareStyle.ForcedBehind,
                reason
            );
        }
        yield return null;
    }

    // STRING REASON PARAMETRESİNİ EKLİYORUZ
    private IEnumerator ExecuteSmartJumpscare(string reason)
    {
        currentState = LeesState.Jumpscare;
        ShowModel(true);
        if (JumpscareManager.Instance != null)
        {
            // REASON'I JUMPSCARE MANAGER'A İLETİYORUZ
            JumpscareManager.Instance.StartJumpscare(
                transform,
                leesJumpscareProfile,
                true,
                JumpscareStyle.SmartDisplacement,
                reason
            );
        }
        yield return null;
    }

    // -------------------------------

    private void CheckSpawnLogic()
    {
        if (
            currentCooldownTimer > 0
            || currentState == LeesState.Active
            || currentState == LeesState.Jumpscare
            || currentRoom == null
            || !currentRoom.isDangerous
        )
            return;

        if (GlobalEnemyManager.Instance != null && !GlobalEnemyManager.Instance.CanAttack())
            return;

        float chance = baseSpawnChance + (timeSpentInCurrentRoom * chanceIncreasePerSecond);
        if (Random.Range(0f, 100f) < Mathf.Clamp(chance, 0f, 90f))
            SpawnLeesInRoom();
    }

    public void SpawnLeesInRoom()
    {
        if (currentRoom == null || currentRoom.spawnPoints.Count == 0)
            return;

        Transform bestPoint = GetSafeSpawnPoint();
        if (bestPoint == null)
        {
            Debug.Log("Lees: Spawn iptal (Görüş açısında yer yok)");
            return;
        }

        StopShock();
        if (resistance != null) resistance.CancelResistance();
        StopEncounterAudio();
        spawnRoom = currentRoom;
        transform.position = bestPoint.position;
        transform.LookAt(
            new Vector3(
                playerTransform.position.x,
                transform.position.y,
                playerTransform.position.z
            )
        );

        if (GlobalEnemyManager.Instance != null)
            GlobalEnemyManager.Instance.RegisterAttackStart();

        currentState = LeesState.Active;
        timeSpentInCurrentRoom = 0;
        currentIgnoranceTimer = 0;
        currentReactionTimer = 0;
        currentSurvivalTimer = 0;
        currentMovementGraceTimer = 0;
        HasBeenSpotted = false;
        hasTurnedAway = false;
        lastPlayerPos = playerTransform.position;

        ShowModel(true);
        if (leesAnimator != null)
        {
            leesAnimator.Rebind();
            leesAnimator.Update(0f);
        }
        Debug.Log($"Lees Spawn Oldu! Nokta: {bestPoint.name}");
    }

    private Transform GetSafeSpawnPoint()
    {
        if (currentRoom == null || currentRoom.spawnPoints.Count == 0)
            return null;

        // RAM Optimizasyonu: Yeni Liste yerine önbellek kullan
        shuffleBuffer.Clear();
        shuffleBuffer.AddRange(currentRoom.spawnPoints);

        // Fisher-Yates shuffle
        for (int i = 0; i < shuffleBuffer.Count; i++)
        {
            Transform temp = shuffleBuffer[i];
            int randomIndex = Random.Range(i, shuffleBuffer.Count);
            shuffleBuffer[i] = shuffleBuffer[randomIndex];
            shuffleBuffer[randomIndex] = temp;
        }

        foreach (Transform point in shuffleBuffer)
        {
            if (!IsPositionVisibleToPlayer(point.position))
                return point;
        }
        return null;
    }

    private bool IsPositionVisibleToPlayer(Vector3 position)
    {
        if (playerCamera == null)
            return false;

        // 1. EKRAN KONTROLÜ (Genişletilmiş)
        // Sadece ekranın içi değil, kenarlardan biraz dışarısını da "görüyor" sayıyoruz (-0.2 ile 1.2 arası).
        // Böylece kafanı milim çevirince adam dibinde bitmez.
        Vector3 vp = playerCamera.WorldToViewportPoint(position);
        bool inScreen = vp.z > 0 && vp.x > -0.2f && vp.x < 1.2f && vp.y > -0.2f && vp.y < 1.2f;

        if (!inScreen)
            return false; // Ekranda (veya yakınında) değilse -> GÖRÜNMÜYOR (Spawn Olabilir).

        // 2. ENGEL KONTROLÜ (Spawn Noktasından -> Kameraya)
        // Işını tersten atıyoruz ki karakterin kendisine çarpıp "duvar var" sanmasın.
        Vector3 dirToCam = playerCamera.transform.position - position;
        float dist = dirToCam.magnitude;

        // ÖNEMLİ: obstacleMask sadece DUVARLARI içermeli.
        if (Physics.Raycast(position, dirToCam.normalized, out RaycastHit hit, dist, obstacleMask))
        {
            // Işın yolda bir şeye çarptı.

            // Eğer çarptığı şey OYUNCU ise, arada engel yok demektir -> GÖRÜNÜYOR (Spawn OLMA).
            if (hit.transform.root == transform.root || hit.transform.CompareTag("Player"))
                return true;

            // Oyuncu değilse (Duvar, Dolap vs.) -> GÖRÜNMÜYOR (Spawn OLABİLİR).
            return false;
        }

        // Hiçbir şeye çarpmadan kameraya ulaştıysa -> Arası boş -> GÖRÜNÜYOR (Spawn OLMA).
        return true;
    }

    public void DespawnLees()
    {
        if (resistance != null) resistance.CancelResistance();
        isSafeSpawn = false;
        if (GlobalEnemyManager.Instance != null && currentState == LeesState.Active)
            GlobalEnemyManager.Instance.RegisterAttackEnd();

        StartFadeAudio(null, false);
        currentState = LeesState.Hidden;
        ShowModel(false);
        currentCooldownTimer = spawnCooldownAfterDespawn;
    }

    private void ShowModel(bool show)
    {
        // RAM Optimizasyonu: Önbelleklenmiş array'leri kullan
        if (cachedRenderers != null)
        {
            foreach (var r in cachedRenderers)
                if (r != null)
                    r.enabled = show;
        }
        if (cachedColliders != null)
        {
            foreach (var c in cachedColliders)
                if (c != null)
                    c.enabled = show;
        }
    }

    public void EnterRoom(RoomManager room) => currentRoom = room;

    public void ExitRoom(RoomManager room)
    {
        if (currentRoom == room)
            currentRoom = null;
    }

    public float GetCurrentSpawnChance() =>
        (currentRoom != null && currentRoom.isDangerous)
            ? Mathf.Clamp(
                baseSpawnChance + (timeSpentInCurrentRoom * chanceIncreasePerSecond),
                0f,
                90f
            )
            : 0f;
}
